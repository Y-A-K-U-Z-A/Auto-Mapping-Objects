package com.example.domain.entities;

public enum Role {
    ADMIN, USER;
}
